import 'package:flutter_test/flutter_test.dart';
import 'package:autobots/calc.dart';

void main() {
  test('220 V, 24-0-24 V 5 A', () {
    final r = calculate(
      primaryVolts: 220,
      windings: const [WindingInput('Secondary', 24, 5, WindingType.centerTap)],
    );
    expect(r.totalPowerVA, 240);
    expect(r.turnsPerVolt, closeTo(2.711, 0.01));
    expect(r.primary.turns.round(), 596);
  });
}
