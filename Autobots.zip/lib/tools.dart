part of 'main.dart';

/// Extra helpers from the same DIY method:
///  • amplifier DC rail → transformer AC voltage
///  • AC voltage → DC after bridge rectifier
///  • EI (laminated) core finder: area = √P, turns/volt = 42 / area
class ToolsScreen extends StatefulWidget {
  const ToolsScreen({super.key});
  @override
  State<ToolsScreen> createState() => _ToolsScreenState();
}

class _ToolsScreenState extends State<ToolsScreen> {
  final dc = TextEditingController();
  final ac = TextEditingController();
  final watts = TextEditingController();

  @override
  void initState() {
    super.initState();
    for (final c in [dc, ac, watts]) {
      c.addListener(() => setState(() {}));
    }
  }

  @override
  void dispose() {
    dc.dispose();
    ac.dispose();
    watts.dispose();
    super.dispose();
  }

  static const _tongues = [1.6, 2.2, 2.5, 2.8, 3.2, 3.8, 4.4, 5.0];

  @override
  Widget build(BuildContext context) {
    final vdc = parseNum(dc.text);
    final vac = parseNum(ac.text);
    final p = parseNum(watts.text);

    final acFromDc = vdc == null ? null : (vdc + 1.4) / math.sqrt2;
    final dcFromAc = vac == null ? null : math.max(0.0, vac * math.sqrt2 - 1.4);

    final rows = <List<String>>[];
    if (p != null && p > 0) {
      final area = math.sqrt(p);
      for (final x in _tongues) {
        final y = area / x;
        // Sensible stacks only: between ~0.8x and 2.5x the tongue width.
        if (y < x * 0.8 || y > x * 2.5) continue;
        final stack = (y * 2).ceil() / 2; // round up to 0.5 cm
        final a = x * stack;
        rows.add([
          '${x.toStringAsFixed(1)} × ${stack.toStringAsFixed(1)}',
          a.toStringAsFixed(1),
          '${(a * a).round()}',
          (42 / a).toStringAsFixed(2),
        ]);
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('TOOLS'),
        automaticallyImplyLeading: false,
        bottom: const PreferredSize(
            preferredSize: Size.fromHeight(4), child: _Stripe()),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 28),
        children: [
          _Section(title: 'Amplifier DC rail → AC', accent: AB.red, children: [
            _Field(dc, 'Amplifier supply (V DC)',
                help: 'Enter the DC rail your amplifier needs (per rail, e.g. 35 for ±35 V). '
                    'The app gives the AC winding voltage: (Vdc + 1.4) ÷ 1.414.'),
            _result(acFromDc == null
                ? 'Transformer: — V AC'
                : 'Transformer: ${acFromDc.toStringAsFixed(1)} V AC'
                    '  (use ${acFromDc.toStringAsFixed(0)}-0-${acFromDc.toStringAsFixed(0)} for ± rails)'),
          ]),
          const SizedBox(height: 12),
          _Section(title: 'AC → DC after rectifier', accent: AB.blue, children: [
            _Field(ac, 'Winding voltage (V AC)',
                help: 'AC voltage of a winding. DC after a bridge rectifier and filter capacitor '
                    '≈ Vac × 1.414 − 1.4 V (unloaded).'),
            _result(dcFromAc == null
                ? 'DC: — V'
                : 'DC: ≈ ${dcFromAc.toStringAsFixed(1)} V'),
          ]),
          const SizedBox(height: 12),
          _Section(title: 'EI core finder', accent: AB.blue, children: [
            _Field(watts, 'Power needed (W)',
                help: 'For laminated E-I cores. Core area = tongue width × stack depth (cm). '
                    'Needed area = √Power. The table lists practical sizes that reach it.'),
            if (p != null && p > 0) ...[
              _result('Area needed: ${math.sqrt(p).toStringAsFixed(1)} cm²'),
              const SizedBox(height: 6),
              _table(rows),
            ],
            const SizedBox(height: 8),
          ]),
        ],
      ),
    );
  }

  Widget _result(String text) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AB.steel,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AB.panelEdge),
        ),
        child: Text(text,
            style: const TextStyle(
                color: AB.amber, fontSize: 16, fontWeight: FontWeight.w700)),
      );

  Widget _table(List<List<String>> rows) {
    const head = TextStyle(color: AB.silver, fontWeight: FontWeight.w700, fontSize: 13);
    const cell = TextStyle(color: AB.chrome, fontSize: 14);
    Widget row(List<String> r, TextStyle s) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Expanded(flex: 4, child: Text(r[0], style: s)),
            Expanded(flex: 3, child: Text(r[1], style: s, textAlign: TextAlign.right)),
            Expanded(flex: 3, child: Text(r[2], style: s, textAlign: TextAlign.right)),
            Expanded(flex: 3, child: Text(r[3], style: s, textAlign: TextAlign.right)),
          ]),
        );
    if (rows.isEmpty) {
      return const Text('No standard size fits — combine cores or use a toroid.',
          style: TextStyle(color: AB.silver));
    }
    return Column(children: [
      row(['Core (cm)', 'Area cm²', 'Max W', 'Turns/V'], head),
      const Divider(color: AB.panelEdge, height: 1),
      for (final r in rows) row(r, cell),
    ]);
  }
}
