import 'dart:math' as math;

/// Winding style: a plain two-wire winding, or a centre-tapped one (V-0-V).
enum WindingType { simple, centerTap }

class WindingInput {
  final String name;
  final double volts; // for centre tap: volts per half (e.g. 24 for 24-0-24)
  final double amps;
  final WindingType type;
  const WindingInput(this.name, this.volts, this.amps, this.type);
}

class WindingResult {
  final String name;
  final double volts;
  final double amps;
  final WindingType type;
  final double turns; // total turns of the winding
  final int awg;
  final double wireDiaMm;
  final double lengthM;
  final double weightG;
  final double powerVA;
  final double dcAfterBridge;
  const WindingResult({
    required this.name,
    required this.volts,
    required this.amps,
    required this.type,
    required this.turns,
    required this.awg,
    required this.wireDiaMm,
    required this.lengthM,
    required this.weightG,
    required this.powerVA,
    required this.dcAfterBridge,
  });

  String get voltLabel => type == WindingType.centerTap
      ? '${fmt(volts)}-0-${fmt(volts)} V'
      : '${fmt(volts)} V';
}

class CoreDims {
  final double outerCm, innerCm, heightCm;
  const CoreDims(this.outerCm, this.innerCm, this.heightCm);
  double get areaCm2 => (outerCm - innerCm) * heightCm / 2;
  double get windowCm2 => math.pi * math.pow(innerCm / 2, 2);
  double get turnLengthCm => (outerCm - innerCm) + 2 * heightCm;
}

class TransformerResult {
  final double totalPowerVA;
  final double requiredAreaCm2;
  final double usedAreaCm2;
  final double turnsPerVolt;
  final WindingResult primary;
  final List<WindingResult> secondaries;
  final CoreDims? givenCore;
  final CoreDims suggestedCore;
  final double? windowFillPct;
  final double maxPowerOfGivenCore;
  final List<String> warnings;
  const TransformerResult({
    required this.totalPowerVA,
    required this.requiredAreaCm2,
    required this.usedAreaCm2,
    required this.turnsPerVolt,
    required this.primary,
    required this.secondaries,
    required this.givenCore,
    required this.suggestedCore,
    required this.windowFillPct,
    required this.maxPowerOfGivenCore,
    required this.warnings,
  });
}

String fmt(double v, [int digits = 1]) {
  if (v == v.roundToDouble()) return v.toStringAsFixed(0);
  return v.toStringAsFixed(digits);
}

/// AWG wire diameter in mm.
double awgDiameterMm(int n) => 0.127 * math.pow(92, (36 - n) / 39).toDouble();

/// Thinnest AWG whose cross-section carries [amps] at [density] A/mm².
int pickAwg(double amps, double density) {
  final reqArea = amps / density; // mm²
  for (int n = 40; n >= 0; n--) {
    final d = awgDiameterMm(n);
    if (math.pi * d * d / 4 >= reqArea) return n;
  }
  return 0;
}

/// Classic DIY method (construyasuvideorockola.com and similar):
///   core area (cm²) = √P ;  turns per volt = 42 / area ;
///   toroid area = (De − Di) × h / 2.
/// Wire sized by current density (default 2.5 A/mm²).
TransformerResult calculate({
  required double primaryVolts,
  required List<WindingInput> windings,
  CoreDims? core,
  double constant = 42,
  double currentDensity = 2.5,
  double efficiency = 0.9,
}) {
  final warnings = <String>[];

  double powerOf(WindingInput w) =>
      w.type == WindingType.centerTap ? 2 * w.volts * w.amps : w.volts * w.amps;

  final totalP = windings.fold<double>(0, (s, w) => s + powerOf(w));
  final requiredArea = math.sqrt(totalP);

  double usedArea = requiredArea;
  if (core != null) {
    usedArea = core.areaCm2;
    if (usedArea < requiredArea * 0.95) {
      warnings.add(
          'Core is too small: ${fmt(usedArea, 2)} cm² vs ${fmt(requiredArea, 2)} cm² needed. '
          'It can handle about ${fmt(usedArea * usedArea, 0)} VA — it will overheat at ${fmt(totalP, 0)} VA.');
    }
  }
  final tpv = constant / usedArea;

  // Suggested square-section toroid (h = radial width = √A).
  final side = math.sqrt(requiredArea);

  // First pass: wire sizes (independent of core geometry).
  final primaryAmps = totalP / (primaryVolts * efficiency);
  final pAwg = pickAwg(primaryAmps, currentDensity);
  final pTurns = primaryVolts * tpv;

  final secTurns = <double>[];
  final secAwg = <int>[];
  for (final w in windings) {
    final t = (w.type == WindingType.centerTap ? 2 : 1) * w.volts * tpv;
    secTurns.add(t);
    secAwg.add(pickAwg(w.amps, currentDensity));
  }

  double copperArea(int awg, double turns) {
    final d = awgDiameterMm(awg) * 1.08 / 10; // cm, incl. enamel
    return turns * math.pi * d * d / 4;
  }

  double totalCu = copperArea(pAwg, pTurns);
  for (int i = 0; i < windings.length; i++) {
    totalCu += copperArea(secAwg[i], secTurns[i]);
  }
  // Toroid hole needs room for winding: aim for ≤35% fill.
  final neededWindow = totalCu / 0.35;
  final sugInner =
      math.max(side * 1.2, math.sqrt(4 * neededWindow / math.pi));
  final suggested = CoreDims(sugInner + 2 * side, sugInner, side);

  final geom = core ?? suggested;
  double? fill;
  if (core != null) {
    fill = totalCu / core.windowCm2 * 100;
    if (fill > 45) {
      warnings.add(
          'Hole too small for the wire (${fmt(fill, 0)}% fill). Hand winding is practical up to ~35-40%. '
          'Pick a core with a larger inner diameter.');
    }
  }

  // Mean turn length grows as layers build up: +20%.
  final turnLenCm = geom.turnLengthCm * 1.2;

  WindingResult build(String name, double v, double a, WindingType type,
      double turns, int awg, double p) {
    final d = awgDiameterMm(awg);
    final lengthM = turns * turnLenCm / 100;
    final weightG = lengthM * 100 * math.pi * math.pow(d / 20, 2) * 8.96;
    final vPeak = v * math.sqrt2;
    return WindingResult(
      name: name,
      volts: v,
      amps: a,
      type: type,
      turns: turns,
      awg: awg,
      wireDiaMm: d,
      lengthM: lengthM,
      weightG: weightG,
      powerVA: p,
      dcAfterBridge: math.max(
          0.0, type == WindingType.centerTap ? vPeak - 0.7 : vPeak - 1.4),
    );
  }

  final primary = build('Primary', primaryVolts, primaryAmps,
      WindingType.simple, pTurns, pAwg, totalP / efficiency);
  final secs = <WindingResult>[];
  for (int i = 0; i < windings.length; i++) {
    final w = windings[i];
    secs.add(build(w.name, w.volts, w.amps, w.type, secTurns[i], secAwg[i],
        powerOf(w)));
    if (secAwg[i] <= 8) {
      warnings.add(
          '${w.name}: AWG ${secAwg[i]} is very thick to wind by hand — use 2-4 thinner wires in parallel of equal total area.');
    }
  }

  return TransformerResult(
    totalPowerVA: totalP,
    requiredAreaCm2: requiredArea,
    usedAreaCm2: usedArea,
    turnsPerVolt: tpv,
    primary: primary,
    secondaries: secs,
    givenCore: core,
    suggestedCore: suggested,
    windowFillPct: fill,
    maxPowerOfGivenCore: core == null ? 0 : core.areaCm2 * core.areaCm2,
    warnings: warnings,
  );
}
