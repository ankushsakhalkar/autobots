import 'package:flutter/material.dart';

/// Optimus Prime palette: cab red, trailer blue, chrome silver, dark steel.
class AB {
  static const red = Color(0xFFD7182A);
  static const redDark = Color(0xFF8E0E1A);
  static const blue = Color(0xFF1E5AA8);
  static const blueDark = Color(0xFF0F2F5C);
  static const silver = Color(0xFFC9CED6);
  static const chrome = Color(0xFFE9ECF1);
  static const steel = Color(0xFF0A0F1A);
  static const panel = Color(0xFF111C30);
  static const panelEdge = Color(0xFF26446F);
  static const amber = Color(0xFFF5B400);

  static ThemeData theme() {
    final scheme = ColorScheme.fromSeed(
      seedColor: red,
      brightness: Brightness.dark,
      primary: red,
      onPrimary: Colors.white,
      secondary: blue,
      onSecondary: Colors.white,
      surface: panel,
      onSurface: chrome,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: steel,
      appBarTheme: const AppBarTheme(
        backgroundColor: redDark,
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        titleTextStyle: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w800,
            letterSpacing: 3,
            color: Colors.white),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: chrome,
        hintStyle: const TextStyle(color: Color(0xFF6B7380)),
        labelStyle: const TextStyle(color: Color(0xFF3A4352)),
        floatingLabelStyle: const TextStyle(color: blue),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: blue, width: 2)),
      ),
    );
  }
}
