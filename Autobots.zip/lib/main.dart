import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'calc.dart';
import 'theme.dart';
part 'tools.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: AB.redDark,
    systemNavigationBarColor: AB.steel,
  ));
  runApp(const AutobotsApp());
}

class AutobotsApp extends StatelessWidget {
  const AutobotsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Autobots',
      debugShowCheckedModeBanner: false,
      theme: AB.theme(),
      home: const HomeShell(),
    );
  }
}

/// Fast page route: 140 ms fade instead of the default slide.
Route<T> fastRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 140),
      reverseTransitionDuration: const Duration(milliseconds: 110),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, a, __, child) =>
          FadeTransition(opacity: a, child: child),
    );

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  static const _pages = [CalculatorScreen(), ToolsScreen(), HelpScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // IndexedStack keeps every tab alive: switching is instant and
      // typed values are not lost.
      body: IndexedStack(index: tab, children: _pages),
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          backgroundColor: AB.redDark,
          indicatorColor: AB.blue,
          height: 68,
          labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: s.contains(WidgetState.selected) ? Colors.white : AB.silver,
              )),
          iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
                size: 26,
                color: s.contains(WidgetState.selected) ? AB.amber : AB.silver,
              )),
        ),
        child: NavigationBar(
          selectedIndex: tab,
          animationDuration: const Duration(milliseconds: 120),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) {
            FocusScope.of(context).unfocus();
            setState(() => tab = i);
          },
          destinations: const [
            NavigationDestination(icon: Icon(Icons.calculate_outlined), selectedIcon: Icon(Icons.calculate), label: 'Calculator'),
            NavigationDestination(icon: Icon(Icons.build_outlined), selectedIcon: Icon(Icons.build), label: 'Tools'),
            NavigationDestination(icon: Icon(Icons.help_outline), selectedIcon: Icon(Icons.help), label: 'Help'),
          ],
        ),
      ),
    );
  }
}

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const body = TextStyle(color: AB.chrome, fontSize: 16, height: 1.5);
    return Scaffold(
      appBar: AppBar(
        title: const Text('HELP'),
        automaticallyImplyLeading: false,
        bottom: const PreferredSize(preferredSize: Size.fromHeight(4), child: _Stripe()),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 28),
        children: const [
          _Section(title: 'How to use', accent: AB.red, children: [
            Padding(padding: EdgeInsets.only(bottom: 12), child: Text(helpText, style: body)),
          ]),
          SizedBox(height: 12),
          _Section(title: 'About Autobots', accent: AB.blue, children: [
            Padding(padding: EdgeInsets.only(bottom: 12), child: Text(aboutText, style: body)),
          ]),
        ],
      ),
    );
  }
}

double? parseNum(String s) {
  final t = s.trim().replaceAll(',', '.');
  if (t.isEmpty) return null;
  return double.tryParse(t);
}

Future<void> showHelp(BuildContext context, String title, String body) {
  return showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AB.panel,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AB.panelEdge)),
      title: Text(title,
          textAlign: TextAlign.center,
          style: const TextStyle(
              color: AB.chrome, fontWeight: FontWeight.w700)),
      content: Text(body,
          style: const TextStyle(color: AB.silver, fontSize: 15, height: 1.4)),
      actions: [
        OutlinedButton(
          style: OutlinedButton.styleFrom(
              foregroundColor: AB.amber,
              side: const BorderSide(color: AB.amber)),
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Got it'),
        )
      ],
    ),
  );
}

// ───────────────────────────── Calculator screen ─────────────────────────────

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});
  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  final vIn = TextEditingController(text: '230');
  final dOut = TextEditingController();
  final dIn = TextEditingController();
  final h = TextEditingController();
  final v1 = TextEditingController();
  final a1 = TextEditingController();
  final v2 = TextEditingController();
  final a2 = TextEditingController();
  final kConst = TextEditingController(text: '42');
  final density = TextEditingController(text: '2.5');
  WindingType t1 = WindingType.simple;
  WindingType t2 = WindingType.simple;

  @override
  void dispose() {
    for (final c in [vIn, dOut, dIn, h, v1, a1, v2, a2, kConst, density]) {
      c.dispose();
    }
    super.dispose();
  }

  void _error(String msg) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        backgroundColor: AB.redDark,
        content: Text(msg, style: const TextStyle(color: Colors.white)),
      ));
  }

  void _calculate() {
    FocusScope.of(context).unfocus();
    final vp = parseNum(vIn.text);
    if (vp == null || vp <= 0) return _error('Enter the input (mains) voltage.');

    final sv = parseNum(v1.text), sa = parseNum(a1.text);
    if (sv == null || sa == null || sv <= 0 || sa <= 0) {
      return _error('Enter the secondary output voltage and current.');
    }
    final windings = [WindingInput('Secondary', sv, sa, t1)];

    final xv = parseNum(v2.text), xa = parseNum(a2.text);
    if ((xv != null) != (xa != null)) {
      return _error('Additional winding: fill both voltage and current, or leave both empty.');
    }
    if (xv != null && xa != null) {
      if (xv <= 0 || xa <= 0) return _error('Additional winding values must be above zero.');
      windings.add(WindingInput('Additional', xv, xa, t2));
    }

    final de = parseNum(dOut.text), di = parseNum(dIn.text), hh = parseNum(h.text);
    final anyCore = de != null || di != null || hh != null;
    CoreDims? core;
    if (anyCore) {
      if (de == null || di == null || hh == null) {
        return _error('Core: fill all three sizes (outer, inner, height) or leave all empty.');
      }
      if (de <= di || di <= 0 || hh <= 0) {
        return _error('Core: outer diameter must be larger than inner diameter.');
      }
      core = CoreDims(de, di, hh);
    }

    final k = parseNum(kConst.text) ?? 42;
    final j = parseNum(density.text) ?? 2.5;
    if (k <= 0 || j <= 0) return _error('Advanced values must be above zero.');

    final result = calculate(
      primaryVolts: vp,
      windings: windings,
      core: core,
      constant: k,
      currentDensity: j,
    );
    Navigator.push(context, fastRoute(ResultsScreen(result: result)));
  }

  void _reset() {
    setState(() {
      for (final c in [dOut, dIn, h, v1, a1, v2, a2]) {
        c.clear();
      }
      vIn.text = '230';
      kConst.text = '42';
      density.text = '2.5';
      t1 = WindingType.simple;
      t2 = WindingType.simple;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AUTOBOTS'),
        automaticallyImplyLeading: false,
        leading: const Padding(
          padding: EdgeInsets.all(10),
          child: _Badge(),
        ),
        actions: [
          TextButton.icon(
            style: TextButton.styleFrom(foregroundColor: Colors.white),
            onPressed: _reset,
            icon: const Icon(Icons.restart_alt),
            label: const Text('Reset'),
          ),
        ],
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(4),
          child: _Stripe(),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 28),
          children: [
            _Section(
              title: 'Primary winding',
              accent: AB.red,
              children: [
                _Field(vIn, 'Input voltage (V)',
                    help: 'Mains voltage that powers the transformer. India uses 230 V (220-240 V). '
                        'Americas mostly 110-127 V.'),
              ],
            ),
            const SizedBox(height: 12),
            _CoreRow(dOut: dOut, dIn: dIn, h: h),
            const SizedBox(height: 12),
            _Section(
              title: 'Secondary winding',
              accent: AB.blue,
              children: [
                _Field(v1, 'Output voltage (V AC)',
                    help: 'AC voltage you want from this winding. For Center Tap, enter the voltage of '
                        'each half — e.g. 24 for a 24-0-24 V transformer.'),
                _Field(a1, 'Output current (A)',
                    help: 'Maximum current this winding must deliver, in amperes.'),
                _TypePicker(t1, (v) => setState(() => t1 = v)),
              ],
            ),
            const SizedBox(height: 12),
            _Section(
              title: 'Additional winding (optional)',
              accent: AB.blue,
              children: [
                _Field(v2, 'Output voltage (V AC)',
                    help: 'An optional second output, e.g. 12 V for a fan or preamp. Leave empty if not needed.'),
                _Field(a2, 'Output current (A)',
                    help: 'Maximum current for the additional winding, in amperes.'),
                _TypePicker(t2, (v) => setState(() => t2 = v)),
              ],
            ),
            const SizedBox(height: 12),
            Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: Container(
                decoration: _panelDeco(AB.silver),
                child: ExpansionTile(
                  iconColor: AB.silver,
                  collapsedIconColor: AB.silver,
                  title: const Text('Advanced',
                      style: TextStyle(color: AB.chrome, fontWeight: FontWeight.w600)),
                  childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                  children: [
                    _Field(kConst, 'Turns constant (default 42)',
                        help: 'Turns per volt = constant ÷ core area (cm²). 42 is the classic value for '
                            '50/60 Hz silicon-steel cores. Use 38-40 for a good toroid, 45-50 for poor or unknown steel.'),
                    _Field(density, 'Current density A/mm² (default 2.5)',
                        help: 'How hard the copper is pushed. 2.5 is safe and cool. 3-3.5 gives thinner wire '
                            'but runs warmer — fine for audio amps used intermittently.'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 22),
            SizedBox(
              height: 56,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: AB.red,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _calculate,
                child: const Text('CALCULATE',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

const helpText =
    '1. Enter your mains voltage.\n'
    '2. If you already have a toroidal core, enter its outer diameter, inner diameter (hole) and height in cm. '
    'Leave them empty and the app will suggest a core size.\n'
    '3. Enter each output: AC voltage and current. Pick Center Tap for V-0-V windings.\n'
    '4. Tap Calculate to get turns, wire gauge (AWG), wire length and weight for every winding.\n\n'
    'Method: core area = √Power, turns/volt = 42 ÷ area, toroid area = (Outer − Inner) × Height ÷ 2.';

const aboutText =
    'Autobots — transformer winding calculator for amplifier and power-supply builders.\n\n'
    'Results are a practical DIY starting point. Always insulate the primary well, '
    'fuse the mains side and test unloaded voltages before connecting a load.';

BoxDecoration _panelDeco(Color accent) => BoxDecoration(
      color: AB.panel,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AB.panelEdge),
    );

class _Badge extends StatelessWidget {
  const _Badge();
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
            colors: [AB.blue, AB.blueDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
        border: Border.all(color: AB.silver, width: 1.5),
      ),
      child: const Icon(Icons.bolt, color: AB.amber, size: 22),
    );
  }
}

class _Stripe extends StatelessWidget {
  const _Stripe();
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(flex: 3, child: Container(height: 4, color: AB.silver)),
      Expanded(flex: 5, child: Container(height: 4, color: AB.blue)),
      Expanded(flex: 2, child: Container(height: 4, color: AB.amber)),
    ]);
  }
}

class _Section extends StatelessWidget {
  final String title;
  final Color accent;
  final List<Widget> children;
  const _Section(
      {required this.title, required this.accent, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _panelDeco(accent),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                accent,
                Color.lerp(accent, Colors.black, 0.45)!,
              ]),
            ),
            child: Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController c;
  final String label;
  final String help;
  const _Field(this.c, this.label, {required this.help});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 6),
            child: Text(label,
                style: const TextStyle(
                    color: AB.chrome,
                    fontSize: 15,
                    fontWeight: FontWeight.w600)),
          ),
          Row(children: [
            Expanded(
              child: TextField(
                controller: c,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))
                ],
                style: const TextStyle(
                    color: Color(0xFF0A0F1A),
                    fontSize: 18,
                    fontWeight: FontWeight.w700),
                decoration: const InputDecoration(
                  hintText: 'Enter value',
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 8),
            _HelpButton(title: label, body: help),
          ]),
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  final String title, body;
  const _HelpButton({required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: () => showHelp(context, title, body),
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AB.blue,
          border: Border.all(color: AB.silver, width: 1.5),
        ),
        child: const Icon(Icons.question_mark, size: 20, color: Colors.white),
      ),
    );
  }
}

class _TypePicker extends StatelessWidget {
  final WindingType value;
  final ValueChanged<WindingType> onChanged;
  const _TypePicker(this.value, this.onChanged);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SegmentedButton<WindingType>(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected) ? AB.red : AB.steel),
          foregroundColor: WidgetStateProperty.resolveWith((s) =>
              s.contains(WidgetState.selected) ? Colors.white : AB.silver),
          side: const WidgetStatePropertyAll(BorderSide(color: AB.panelEdge)),
        ),
        segments: const [
          ButtonSegment(value: WindingType.simple, label: Text('Simple')),
          ButtonSegment(value: WindingType.centerTap, label: Text('Center Tap')),
        ],
        selected: {value},
        onSelectionChanged: (s) => onChanged(s.first),
      ),
    );
  }
}

// ───────────────────────────── Core size row ─────────────────────────────

enum CoreDimKind { outer, inner, height }

class _CoreRow extends StatelessWidget {
  final TextEditingController dOut, dIn, h;
  const _CoreRow({required this.dOut, required this.dIn, required this.h});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _panelDeco(AB.silver),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
      child: Column(children: [
        Row(children: [
          const Expanded(
            child: Text('Toroidal core (optional)',
                style: TextStyle(
                    color: AB.chrome, fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          _HelpButton(
              title: 'Toroidal core',
              body: 'Measure your core in centimetres:\n'
                  '• Outer diameter (full width)\n'
                  '• Inner diameter (the hole)\n'
                  '• Height (thickness)\n\n'
                  'Core area = (Outer − Inner) × Height ÷ 2.\n'
                  'Leave all three empty to get a suggested core size.'),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _CoreField(dOut, CoreDimKind.outer, 'Outer')),
          const SizedBox(width: 8),
          Expanded(child: _CoreField(dIn, CoreDimKind.inner, 'Inner')),
          const SizedBox(width: 8),
          Expanded(child: _CoreField(h, CoreDimKind.height, 'Height')),
        ]),
      ]),
    );
  }
}

class _CoreField extends StatelessWidget {
  final TextEditingController c;
  final CoreDimKind kind;
  final String label;
  const _CoreField(this.c, this.kind, this.label);

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SizedBox(
          height: 56,
          width: 56,
          child: CustomPaint(painter: CorePainter(kind))),
      const SizedBox(height: 4),
      Text('$label (cm)',
          style: const TextStyle(
              color: AB.chrome, fontSize: 13, fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      TextField(
        controller: c,
        textAlign: TextAlign.center,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
        style: const TextStyle(
            color: Color(0xFF0A0F1A), fontSize: 16, fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          hintText: '0.0',
          contentPadding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
        ),
      ),
    ]);
  }
}

class CorePainter extends CustomPainter {
  final CoreDimKind kind;
  CorePainter(this.kind);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 2;
    final steel = Paint()
      ..shader = const LinearGradient(
              colors: [AB.chrome, Color(0xFF7D8694)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight)
          .createShader(Offset.zero & size);
    final arrow = Paint()
      ..color = AB.red
      ..strokeWidth = 2.6
      ..strokeCap = StrokeCap.round;

    if (kind == CoreDimKind.height) {
      // Side view: a short cylinder.
      final rect = Rect.fromLTWH(size.width * 0.12, size.height * 0.22,
          size.width * 0.76, size.height * 0.6);
      canvas.drawRRect(
          RRect.fromRectAndRadius(rect, const Radius.circular(6)), steel);
      canvas.drawOval(
          Rect.fromCenter(
              center: Offset(c.dx, rect.top),
              width: rect.width,
              height: size.height * 0.24),
          Paint()..color = AB.silver);
      canvas.drawOval(
          Rect.fromCenter(
              center: Offset(c.dx, rect.top),
              width: rect.width * 0.45,
              height: size.height * 0.11),
          Paint()..color = AB.steel);
      _arrow(canvas, Offset(size.width * 0.95, rect.top),
          Offset(size.width * 0.95, rect.bottom), arrow);
      return;
    }
    canvas.drawCircle(c, r, steel);
    canvas.drawCircle(c, r * 0.48, Paint()..color = AB.panel);
    if (kind == CoreDimKind.outer) {
      _arrow(canvas, Offset(c.dx - r, c.dy), Offset(c.dx + r, c.dy), arrow);
    } else {
      _arrow(canvas, Offset(c.dx - r * 0.46, c.dy),
          Offset(c.dx + r * 0.46, c.dy), arrow);
    }
  }

  void _arrow(Canvas canvas, Offset a, Offset b, Paint p) {
    canvas.drawLine(a, b, p);
    final ang = math.atan2(b.dy - a.dy, b.dx - a.dx);
    const head = 6.0;
    for (final end in [a, b]) {
      final dir = end == a ? ang + math.pi : ang;
      canvas.drawLine(end,
          end - Offset(math.cos(dir - 0.5), math.sin(dir - 0.5)) * head, p);
      canvas.drawLine(end,
          end - Offset(math.cos(dir + 0.5), math.sin(dir + 0.5)) * head, p);
    }
  }

  @override
  bool shouldRepaint(covariant CorePainter old) => old.kind != kind;
}

// ───────────────────────────── Results screen ─────────────────────────────

class ResultsScreen extends StatelessWidget {
  final TransformerResult result;
  const ResultsScreen({super.key, required this.result});

  String _summary() {
    final r = result;
    final b = StringBuffer()
      ..writeln('AUTOBOTS — transformer design')
      ..writeln('Power: ${fmt(r.totalPowerVA, 0)} VA')
      ..writeln('Core area: ${fmt(r.usedAreaCm2, 2)} cm² (needed ${fmt(r.requiredAreaCm2, 2)})')
      ..writeln('Turns per volt: ${r.turnsPerVolt.toStringAsFixed(3)}');
    for (final w in [r.primary, ...r.secondaries]) {
      b.writeln('${w.name} ${w.voltLabel}: ${w.turns.round()} turns, '
          'AWG ${w.awg} (${w.wireDiaMm.toStringAsFixed(2)} mm), '
          '${w.lengthM.toStringAsFixed(1)} m, ${w.weightG.round()} g');
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final r = result;
    final core = r.givenCore ?? r.suggestedCore;
    return Scaffold(
      appBar: AppBar(
        title: const Text('RESULTS'),
        actions: [
          IconButton(
            tooltip: 'Copy',
            icon: const Icon(Icons.copy),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: _summary()));
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Results copied')));
            },
          )
        ],
        bottom: const PreferredSize(
            preferredSize: Size.fromHeight(4), child: _Stripe()),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 28),
        children: [
          for (final w in r.warnings)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0x33F5B400),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AB.amber),
              ),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.warning_amber_rounded, color: AB.amber),
                const SizedBox(width: 10),
                Expanded(
                    child: Text(w,
                        style: const TextStyle(color: AB.chrome, height: 1.35))),
              ]),
            ),
          _Section(title: 'Core', accent: AB.red, children: [
            _kv('Total power', '${fmt(r.totalPowerVA, 0)} VA'),
            _kv('Core area needed', '${fmt(r.requiredAreaCm2, 2)} cm²'),
            if (r.givenCore != null) ...[
              _kv('Your core area', '${fmt(r.usedAreaCm2, 2)} cm²'),
              _kv('Your core max power', '≈ ${fmt(r.maxPowerOfGivenCore, 0)} VA'),
              _kv('Window fill', '${fmt(r.windowFillPct ?? 0, 0)} %'),
            ] else ...[
              _kv('Suggested outer Ø', '${core.outerCm.toStringAsFixed(1)} cm'),
              _kv('Suggested inner Ø', '${core.innerCm.toStringAsFixed(1)} cm'),
              _kv('Suggested height', '${core.heightCm.toStringAsFixed(1)} cm'),
            ],
            _kv('Turns per volt', r.turnsPerVolt.toStringAsFixed(3), big: true),
            const SizedBox(height: 6),
          ]),
          const SizedBox(height: 12),
          _windingCard(r.primary, AB.red),
          for (final w in r.secondaries) ...[
            const SizedBox(height: 12),
            _windingCard(w, AB.blue),
          ],
          const SizedBox(height: 14),
          const Text(
            'Wind the primary first and insulate it well before the secondaries. '
            'Unloaded secondary voltage reads 5-10% above target — that is normal.',
            style: TextStyle(color: AB.silver, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _windingCard(WindingResult w, Color accent) {
    final ct = w.type == WindingType.centerTap;
    return _Section(title: '${w.name} — ${w.voltLabel}', accent: accent, children: [
      _kv('Turns', ct
          ? '${w.turns.round()}  (tap at ${(w.turns / 2).round()})'
          : '${w.turns.round()}', big: true),
      _kv('Current', '${w.amps.toStringAsFixed(2)} A'),
      _kv('Wire', 'AWG ${w.awg}  •  ${w.wireDiaMm.toStringAsFixed(2)} mm'),
      _kv('Wire length', '≈ ${w.lengthM.toStringAsFixed(1)} m'),
      _kv('Copper weight', '≈ ${w.weightG.round()} g'),
      if (w.name != 'Primary')
        _kv('DC after rectifier', '≈ ${w.dcAfterBridge.toStringAsFixed(1)} V'
            '${ct ? ' (±)' : ''}'),
      const SizedBox(height: 6),
    ]);
  }

  Widget _kv(String k, String v, {bool big = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(children: [
          Expanded(
              child: Text(k,
                  style: const TextStyle(color: AB.silver, fontSize: 15))),
          Text(v,
              style: TextStyle(
                  color: big ? AB.amber : AB.chrome,
                  fontSize: big ? 20 : 15,
                  fontWeight: big ? FontWeight.w800 : FontWeight.w600)),
        ]),
      );
}
