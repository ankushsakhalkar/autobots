# Autobots ⚡

Transformer winding calculator for amplifier and power-supply builders — in Optimus Prime red, blue and chrome.

## What it calculates
Enter mains voltage, (optionally) your toroidal core size, and up to two output windings (Simple or Center Tap). You get:

- Total power (VA) and core area needed (area = √P)
- Turns per volt (42 ÷ core area) — constant adjustable in *Advanced*
- Turns for primary and every secondary (centre-tap position shown)
- Wire gauge (AWG) and diameter, sized at 2.5 A/mm² (adjustable)
- Approximate wire length and copper weight
- Core-too-small and window-fill warnings, or a suggested toroid size if you leave the core empty
- DC voltage after the rectifier

**Tools** (menu): amplifier DC rail → AC winding voltage, AC → DC, and an E-I laminated core finder.

Toroid area = (Outer Ø − Inner Ø) × Height ÷ 2 (cm²).

## Get the APK
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder — it is hidden on some computers).
2. Open the **Actions** tab → *Build Autobots APK* runs automatically (≈6-8 min). If Actions asks, click "enable".
3. Download the APK from **Releases** (right side of the repo page) → `Autobots.apk`, or from the run's *Artifacts*.
4. On your phone, allow "Install unknown apps" for your browser/files app and install.

Every push builds a new version. You can also run it manually: Actions → Build Autobots APK → Run workflow.
